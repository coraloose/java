import os

WTF_CSRF_ENABLED = False
SECRET_KEY = 'a-very-secret-secret'

SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:.Zhouyuankun00@localhost/sepDB'
SQLALCHEMY_TRACK_MODIFICATIONS = False

basedir = os.path.abspath(os.path.dirname(__file__))
