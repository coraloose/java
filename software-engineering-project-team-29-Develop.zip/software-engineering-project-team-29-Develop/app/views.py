from app import app, db
from .forms import SignupForm, LoginForm, BookingForm
from .forms import SignupForm, LoginForm
from .models import User
from flask_login import current_user, login_user, logout_user, login_required
from flask import render_template, flash, redirect, url_for, request, jsonify
from flask_login import current_user, login_user, logout_user, login_required

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    app.logger.info('login route request')
    form = LoginForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        user = User.query.filter_by(username=username).first()
        if not user:
            return render_template('new_login.html',
                        title='Log in',
                        message='User does not exist',
                        form=form), 404
        if user.password != password:
            return render_template('new_login.html',
                        title='Log in',
                        message='Wrong passwprd',
                        form=form), 401
        login_user(user)
        return redirect(url_for('index'))
    return render_template('new_login.html',
                        title='Log in',
                        form=form)


@app.route('/signup', methods=['GET', 'POST']) 
def signin():
    app.logger.info('signup route request')
    form = SignupForm()
    if form.validate_on_submit():
        if (User.query.filter_by(username = form.username.data).first()):
            return render_template('new_signup.html',
                           title='Sign up',
                           form=form,
                           status='repeat',
                           message='Username already exist, please change your username'
                        ), 409
        new_user = User(
            username = form.username.data,
            password = form.password.data,
            email = form.email.data,
            permission_level=2
        )
        db.session.add(new_user)
        db.session.commit()
        login_user(new_user)
        return render_template('new_signup.html',
                           title='Sign up',
                           form=form,
                           status='success',
                           message='You have successfully created an account, You can complete your personal information later on the main page'
                        )
    return render_template('new_signup.html',
                           title='Sign up',
                           form=form
                        )

@app.route('/newBooking', methods=['GET', 'POST'])
def newBooking():
    app.logger.info('newBooking route request')
    form = BookingForm
    if form.validate_on_submit():
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('new_booking.html',
                           title='New Booking',
                           form=form
                        )