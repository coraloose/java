from app import db
from flask_login import UserMixin

class Permission(db.Model):
    permission_level = db.Column(db.Integer, primary_key=True, autoincrement=True)
    permission_name = db.Column(db.String(45), unique=True, nullable=False)


class User(db.Model, UserMixin):
    id_user = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), nullable=False)
    password = db.Column(db.String(255), nullable=False)
    permission_level = db.Column(db.Integer, db.ForeignKey('permission.permission_level'), nullable=False)
    permission = db.relationship('Permission', backref=db.backref('users', lazy=True))

    def get_id(self):
        return str(self.id_user)


class CarInformation(db.Model):
    id_car = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_user = db.Column(db.Integer, db.ForeignKey('user.id_user'), nullable=False)
    number_of_passengers = db.Column(db.Integer, nullable=False)
    luggage_capacity = db.Column(db.Integer, nullable=False)
    car_user = db.relationship('User', backref=db.backref('car_information', lazy=True))


class Card(db.Model):
    card_number = db.Column(db.String(30), primary_key=True)
    expired_date = db.Column(db.DateTime, nullable=False)
    cvv = db.Column(db.String(10), nullable=False)
    id_user = db.Column(db.Integer, db.ForeignKey('user.id_user'), nullable=False)
    card_user = db.relationship('User', backref=db.backref('card', lazy=True))

class JourneyDetail(db.Model):
    id_journey_detail = db.Column(db.Integer, primary_key=True, autoincrement=True)
    journey_time = db.Column(db.DateTime, nullable=False)
    journey_S_point = db.Column(db.String(255), nullable=False)
    journey_E_point = db.Column(db.String(255), nullable=False)

    journey_fee = db.Column(db.Numeric, nullable=False)
    number_of_passengers = db.Column(db.Integer, nullable=False)
    luggage_size = db.Column(db.SmallInteger, nullable=False)
    journey_long_term = db.Column(db.SmallInteger, nullable=False)
    ongoing = db.Column(db.SmallInteger, nullable=False)

class JourneyRecord(db.Model):
    id_journey = db.Column(db.Integer, primary_key=True, autoincrement=True)
    id_user_passenger = db.Column(db.Integer, db.ForeignKey('user.id_user'), nullable=True)
    id_user_driver = db.Column(db.Integer, db.ForeignKey('user.id_user'), nullable=True)
    id_journey_detail = db.Column(db.Integer, db.ForeignKey('journey_detail.id_journey_detail'), nullable=False)

    journey = db.relationship('JourneyDetail', backref=db.backref('journey_record', lazy=True))
    passenger = db.relationship('User', foreign_keys=[id_user_passenger], backref=db.backref('journey_record_passenger', lazy=True))
    driver = db.relationship('User', foreign_keys=[id_user_driver], backref=db.backref('journey_record_driver', lazy=True))

