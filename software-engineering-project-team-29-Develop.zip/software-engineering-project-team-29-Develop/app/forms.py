from flask_wtf import FlaskForm
from wtforms import StringField, DateField, TextAreaField, SelectField, FloatField, PasswordField, IntegerField, TimeField
from wtforms.validators import DataRequired, Length, EqualTo, Optional
from wtforms import StringField, DateField, TextAreaField, SelectField, FloatField, PasswordField, IntegerField
from wtforms.fields.simple import SubmitField
from wtforms.validators import DataRequired, Length, EqualTo, Optional, Email


class LoginForm(FlaskForm):
    username = username = StringField('Username', validators=[
        DataRequired(),
        Length(max=20, message="Exceed the limit")
    ])
    password = PasswordField('Password', validators=[
        DataRequired(),
    ])


class SignupForm(FlaskForm):
    username = StringField('Username', validators=[
        DataRequired(),
        Length(max=20, message="Username must be 20 characters or fewer.")
    ])
    password = PasswordField('Password', validators=[
        DataRequired(),
        Length(max=20, message="Password must be 20 characters or fewer."),
        Length(min=10, message="Password must be 10 characters or more.")
    ])
    confirm_password = PasswordField('Confirm Password', validators=[
        DataRequired(),
        EqualTo('password', message="Passwords must match.")
    ])
    email = StringField('Email', validators=[
        DataRequired(),
        Length(max=20, message="Exceed the limit")
    ])

class BookingForm(FlaskForm):
    startLocation = StringField('Start Location', validators=[
        DataRequired(),
        Length(max=20, message="Start location must be 20 characters or fewer.")
    ])
    endLocation = StringField('End Location', validators=[
        DataRequired(),
        Length(max=20, message="End location must be 20 characters or fewer.")
    ])
    date = DateField('Date', validators=[
        DataRequired(),
    ])
    time = TimeField('Time', validators=[
        DataRequired(),
    ])
    capicity = IntegerField('Capicity', validators=[
        DataRequired(),
    ])
    cost = FloatField('Price', validators=[
        DataRequired(),
    ])