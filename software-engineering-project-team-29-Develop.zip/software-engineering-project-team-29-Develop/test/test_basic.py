import unittest
from app import app, db
from app.models import User, Permission
from flask_login import LoginManager


class FlaskTestCase(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        """ Init """
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        app.config['WTF_CSRF_ENABLED'] = False

        cls.app = app.test_client()
        cls.ctx = app.app_context()
        cls.ctx.push()

        db.create_all()

        login_manager = LoginManager()
        login_manager.init_app(app)

        @login_manager.user_loader
        def load_user(user_id):
            return User.query.get(int(user_id))

    def test_home(self):
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Hello World!!!', response.data)

    def test_signup(self):
        """Basic test /signup"""
        p = Permission(permission_level = 2, permission_name = 'User')
        db.session.add(p)
        db.session.commit()
        response = self.app.post('/signup', data={
            'username': 'admin',
            'password': 'password1010',
            'confirm_password': 'password1010',
            'email': 'testemail'
        }, content_type='application/x-www-form-urlencoded')
        self.assertEqual(response.status_code, 200)

        user = User.query.filter_by(username='admin').first()
        self.assertIsNotNone(user, "No data")
        self.assertEqual(user.username, 'admin')
        self.assertEqual(user.password, 'password1010')

    def test_signup_repeat(self):
        """Repeat username /signup"""
        user = User(username = 'user', password = 'password1010', email = 'testeamil', permission_level = 2)
        p = Permission(permission_level = 2, permission_name = 'User')
        db.session.add(p)
        db.session.add(user)
        db.session.commit()
        response = self.app.post('/signup', data={
            'username': 'user',
            'password': 'password1010',
            'confirm_password': 'password1010',
            'email': 'testemail'
        }, content_type='application/x-www-form-urlencoded')
        self.assertEqual(response.status_code, 409)

    def test_login(self):
        """Basic test /login"""
        user = User(username = 'admin', password = 'password1010', email = 'testeamil', permission_level = 1)
        p = Permission(permission_level = 1, permission_name = 'Admin')
        db.session.add(p)
        db.session.add(user)
        db.session.commit()
        response = self.app.post('/login', data={'username': 'admin', 'password': 'password1010'})
        self.assertEqual(response.status_code, 302)

    def test_login_not_exist(self):
        """Username not exist /login"""
        response = self.app.post('/login', data={'username': 'anotexist', 'password': 'password'})
        self.assertEqual(response.status_code, 404)

    def test_login_wrong_password(self):
        """Wrong password /login"""
        user = User(username = 'admin', password = 'password1010', email = 'testeamil', permission_level = 1)
        p = Permission(permission_level = 1, permission_name = 'Admin')
        db.session.add(p)
        db.session.add(user)
        db.session.commit()
        response = self.app.post('/login', data={'username': 'admin', 'password': 'wrongpassword'})
        self.assertEqual(response.status_code, 401)

    def tearDown(self):
        """ clean """
        db.session.remove()
        db.drop_all()
        db.create_all() 


if __name__ == "__main__":
    unittest.main()
