/************************************************************************
University of Leeds
School of Computing
COMP2932- Compiler Design and Construction
Lexer Module

I confirm that the following code has been developed and written by me and it is entirely the result of my own work.
I also confirm that I have not copied any parts of this program from another person or any other source or facilitated someone to copy this program from me.
I confirm that I will not publish the program online or share it with anyone without permission of the module leader.

Student Name:
Student ID:
Email:
Date Work Commenced:
*************************************************************************/


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "lexer.h"


// YOU CAN ADD YOUR OWN FUNCTIONS, DECLARATIONS AND VARIABLES HERE






// IMPLEMENT THE FOLLOWING functions
//***********************************

// Initialise the lexer to read from source file
// file_name is the name of the source file
// This requires opening the file and making any necessary initialisations of the lexer
// If an error occurs, the function should return 0
// if everything goes well the function should return 1
// 全局变量

static FILE* sourceFile = NULL;
static int currentLine = 1;
static int currentChar = ' ';
static int peeked = 0;
static Token peekToken;

// 辅助函数：读取下一个字符
static int readChar() {
    int c = fgetc(sourceFile);
    if (c == '\n') {
        currentLine++;
    }
    return c;
}

// 辅助函数：跳过空白字符
static void skipWhitespace() {
    while (isspace(currentChar)) {
        currentChar = readChar();
    }
}

// 初始化Lexer
int InitLexer (char* file_name) {
    sourceFile = fopen(file_name, "r");
    if (sourceFile == NULL) {
        fprintf(stderr, "Error: Cannot open file %s\n", file_name);
        return 0;
    }
    currentLine = 1;
    currentChar = readChar();
    peeked = 0;
    return 1;
}

// 读取标识符或关键字
static Token readIdentifier() {
    Token t;
    t.ln = currentLine;
    strncpy(t.fl, "yourfile", sizeof(t.fl));  // 可设置为实际文件名
    int idx = 0;
    while (isalnum(currentChar) || currentChar == '_') {
        if (idx < sizeof(t.lx) - 1) {
            t.lx[idx++] = currentChar;
        }
        currentChar = readChar();
    }
    t.lx[idx] = '\0';
    // 这里可以判断是否为关键字，设置 t.tp 为 RESWORD 或 ID
    t.tp = ID; // 示例，实际需根据关键字列表判断
    return t;
}

// 读取数字
static Token readNumber() {
    Token t;
    t.ln = currentLine;
    strncpy(t.fl, "yourfile", sizeof(t.fl));
    int idx = 0;
    while (isdigit(currentChar)) {
        if (idx < sizeof(t.lx) - 1) {
            t.lx[idx++] = currentChar;
        }
        currentChar = readChar();
    }
    t.lx[idx] = '\0';
    t.tp = INT;
    return t;
}

// 读取字符串字面量
static Token readString() {
    Token t;
    t.ln = currentLine;
    strncpy(t.fl, "yourfile", sizeof(t.fl));
    int idx = 0;
    // 跳过起始引号
    currentChar = readChar();
    while (currentChar != '"' && currentChar != EOF) {
        if (currentChar == '\n') { // 字符串中不允许换行
            t.tp = ERR;
            strcpy(t.lx, "NewLnInStr");
            t.ec = NewLnInStr;
            return t;
        }
        if (idx < sizeof(t.lx) - 1) {
            t.lx[idx++] = currentChar;
        }
        currentChar = readChar();
    }
    if (currentChar == EOF) {
        t.tp = ERR;
        strcpy(t.lx, "EofInStr");
        t.ec = EofInStr;
        return t;
    }
    t.lx[idx] = '\0';
    t.tp = STRING;
    // 跳过结束引号
    currentChar = readChar();
    return t;
}

// 获取下一个记号
Token GetNextToken () {
    Token t;
    // 如果有预读记号，则返回它
    if (peeked) {
        peeked = 0;
        return peekToken;
    }
    // 跳过空白和注释（注释处理代码略，可根据需要实现）
    skipWhitespace();

    t.ln = currentLine;
    strncpy(t.fl, "yourfile", sizeof(t.fl));

    if (currentChar == EOF) {
        t.tp = EOFile;
        strcpy(t.lx, "EOF");
        return t;
    }
    
    if (isalpha(currentChar) || currentChar == '_') {
        return readIdentifier();
    }
    if (isdigit(currentChar)) {
        return readNumber();
    }
    if (currentChar == '"') {
        return readString();
    }
    // 处理符号
    // 假设所有其他单字符均为符号
    t.tp = SYMBOL;
    t.lx[0] = currentChar;
    t.lx[1] = '\0';
    currentChar = readChar();
    return t;
}

// 预览下一个记号（不消费）
Token PeekNextToken () {
    if (!peeked) {
        peekToken = GetNextToken();
        peeked = 1;
    }
    return peekToken;
}

// 清理工作
int StopLexer () {
    if (sourceFile) {
        fclose(sourceFile);
        sourceFile = NULL;
    }
    return 1;
}

int main() {
    char filename[256];
    printf("请输入源文件名：");
    scanf("%s", filename);

    // 初始化词法分析器
    if (!InitLexer(filename)) {
        fprintf(stderr, "无法打开文件：%s\n", filename);
        return 1;
    }

    Token t;
    // 不断调用 GetNextToken() 直到遇到文件结束或错误
    do {
        t = GetNextToken();
        // 打印记号类型、记号内容和所在行号
        printf("记号类型：%d, 内容：%s, 行号：%d\n", t.tp, t.lx, t.ln);
    } while (t.tp != EOFile && t.tp != ERR);

    // 清理工作
    StopLexer();
    return 0;
}
