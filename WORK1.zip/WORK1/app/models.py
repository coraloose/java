from app import db


class Permission(db.Model):
    permission_level = db.Column(db.Integer, primary_key=True)
    permission_name = db.Column(db.String(45), unique=True, nullable=False)


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(20))
    password = db.Column(db.String(20))
    email = db.Column(db.String(20))
    permission_level = db.Column(db.Integer, db.ForeignKey('permission.permission_level'), nullable=False)
    permission = db.relationship('Permission', backref=db.backref('users', lazy=True))

