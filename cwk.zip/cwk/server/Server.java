import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Server for the voting system.
 * 
 * Usage:
 *   java Server option1 option2 [option3 ...]
 * 
 * Requirements:
 * - Accept at least two voting options (each a single word).
 * - Use a fixed thread pool with 30 threads to manage client connections.
 * - Process two types of requests:
 *     - "list": return the current voting status.
 *     - "vote <option>": increment the vote count for <option> (if exists).
 * - Log every valid client request into log.txt in the format:
 *      date|time|client IP address|request
 */
public class Server {
    // Map to store voting options and their counts.
    private static Map<String, Integer> voteCounts = new HashMap<>();
    // Lock for synchronizing updates to voteCounts.
    private static ReentrantLock lock = new ReentrantLock();
    // Server listening port.
    private static final int PORT = 7777;
    // Fixed thread pool size.
    private static final int THREAD_POOL_SIZE = 30;
    // Log file to record valid client requests.
    private static File logFile = new File("log.txt");

    public static void main(String[] args) {
        // Check the command line parameters to make sure there are at least two voting options
        if (args.length < 2) {
            System.err.println("Error: At least two voting options are required.");
            System.err.println("Usage: java Server option1 option2 [option3 ...]");
            System.exit(1);
        }
        // Initializes voting options, with all options starting with 0 votes, and checks for duplicate options
        for (String option : args) {
            if (voteCounts.containsKey(option)) {
                System.err.println("Error: Duplicate option '" + option + "' provided. "
                + "Please enter at least two distinct options.");
                System.exit(1);
            }
            voteCounts.put(option, 0);
        }
        // If the log.txt file already exists, delete the old file to ensure that a new log is recorded each time you start
        if (logFile.exists() && !logFile.delete()) {
            System.err.println("Warning: Unable to delete existing log.txt file.");
        }
        
        // Create a fixed-size thread pool
        ExecutorService executor = Executors.newFixedThreadPool(THREAD_POOL_SIZE);
        
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started. Listening on port " + PORT);
            // Continuously listen for client connections
            while (true) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    executor.execute(new ClientHandler(clientSocket));
                } catch (IOException e) {
                    System.err.println("Error accepting client connection: " + e.getMessage());
                }
            }
        } catch (IOException e) {
            System.err.println("Server failed to start on port " + PORT + ": " + e.getMessage());
        } finally {
            executor.shutdown();
        }
    }
    
    /**
     * Record client requests to the log.txt file.
     * The format: yyyy-MM-dd|HH:mm:ss|client IP|request
     *
     * @param clientIP IP address of the client
     * @param request  Request type ("list" or "vote")
     */
    private static void logRequest(String clientIP, String request) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd|HH:mm:ss");
        String logEntry = dateFormat.format(new Date()) + "|" + clientIP + "|" + request;
        try (FileWriter fw = new FileWriter(logFile, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            out.println(logEntry);
        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }
    
    /**
     * An inner class that handles each client connection
     */
    private static class ClientHandler implements Runnable {
        private Socket clientSocket;
        
        public ClientHandler(Socket socket) {
            this.clientSocket = socket;
        }
        
        @Override
        public void run() {
            String clientIP = clientSocket.getInetAddress().getHostAddress();
            try (BufferedReader in = new BufferedReader(
                     new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
                 
                // Read the request from the client
                String request = in.readLine();
                if (request == null || request.trim().isEmpty()) {
                    out.println("Error: Received empty request.");
                    return;
                }
                
                String response;
                // Split the request by space, supporting either "list" or "vote <option>" format
                String[] tokens = request.trim().split("\\s+");
                if (tokens[0].equalsIgnoreCase("list")) {
                    // Constructs a string that returns all voting options and votes
                    StringBuilder sb = new StringBuilder();
                    for (Map.Entry<String, Integer> entry : voteCounts.entrySet()) {
                        sb.append("'").append(entry.getKey()).append("' has ")
                          .append(entry.getValue()).append(" vote(s).\n");
                    }
                    response = sb.toString();
                    logRequest(clientIP, "list");
                } else if (tokens[0].equalsIgnoreCase("vote")) {
                    if (tokens.length < 2) {
                        response = "Error: Missing voting option. Usage: vote <option>";
                    } else {
                        String option = tokens[1];
                        if (voteCounts.containsKey(option)) {
                            // Use locks to ensure thread-safe vote updates
                            lock.lock();
                            try {
                                int current = voteCounts.get(option);
                                voteCounts.put(option, current + 1);
                            } finally {
                                lock.unlock();
                            }
                            response = "Incremented the number of votes for '" + option + "'.";
                            logRequest(clientIP, "vote");
                        } else {
                            response = "Error: Option '" + option + "' does not exist.";
                        }
                    }
                } else {
                    response = "Error: Invalid command. Please use 'list' or 'vote <option>'.";
                }
                // Send a response to the client
                out.println(response);
            } catch (IOException e) {
                System.err.println("Client handler encountered an error for client " 
                                   + clientIP + ": " + e.getMessage());
            } finally {
                try {
                    clientSocket.close();
                } catch(IOException ex) {
                    // Output warning when client connection cannot be closed
                    System.err.println("Warning: Failed to close client socket: " + ex.getMessage());
                }
            }
        }
    }
}
