import java.io.*;
import java.net.*;

/**
 * Client for the voting system.
 * 
 * Usage:
 *   java Client list
 *   java Client vote <option>
 * 
 * This client connects to the server on localhost:7777,
 * sends a request, and prints the server's response.
 */
public class Client {
    // Server address and port number
    private static final String HOST = "localhost";
    private static final int PORT = 7777;
    
    public static void main(String[] args) {
        // Check command line parameters. You must provide at least one parameter
        if (args.length < 1) {
            System.err.println("Usage: java Client <command> [option]");
            System.err.println("Commands: list, vote <option>");
            System.exit(1);
        }
        
        String command = args[0];
        String request;
        // Construct the request string from the command
        if (command.equalsIgnoreCase("list")) {
            request = "list";
        } else if (command.equalsIgnoreCase("vote")) {
            if (args.length < 2) {
                System.err.println("Error: 'vote' command requires an option. Usage: vote <option>");
                System.exit(1);
                return; // Although System.exit terminates, adding a return guarantees that it will compile
            }
            request = "vote " + args[1];
        } else {
            System.err.println("Error: Invalid command. Please use 'list' or 'vote <option>'.");
            System.exit(1);
            return;
        }
        
        // Try to establish a connection with the server and send a request
        try (Socket socket = new Socket(HOST, PORT);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(
                     new InputStreamReader(socket.getInputStream()))) {
            
            out.println(request);
            // Reads and outputs the server response
            String response;
            while ((response = in.readLine()) != null) {
                System.out.println(response);
            }
        } catch (UnknownHostException e) {
            System.err.println("Error: Unknown host " + HOST + ". " + e.getMessage());
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Error: Unable to connect to " + HOST + " on port " + PORT + ". " + e.getMessage());
            System.exit(1);
        }
    }
}
