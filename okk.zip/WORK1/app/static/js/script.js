const signInBtn = document.getElementById("signIn");
const signUpBtn = document.getElementById("signUp");
const authContainer = document.querySelector(".auth-container");

signInBtn.addEventListener("click", () => {
    authContainer.classList.remove("right-panel-active");
});

signUpBtn.addEventListener("click", () => {
    authContainer.classList.add("right-panel-active");
});

// Optional: Prevent default form submission if using AJAX or custom submit
// document.getElementById("form1").addEventListener("submit", (e) => e.preventDefault());
// document.getElementById("form2").addEventListener("submit", (e) => e.preventDefault());
