from app import app, db
from .forms import RegistrationForm, LoginForm
from .models import User, Permission
from flask_login import current_user, login_user, logout_user, login_required
from flask import render_template, flash, redirect, url_for, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash

@app.route('/')
def index():
    return render_template('home.html')

@app.route('/log', methods=['GET', 'POST'])
def log():
    login_form = LoginForm(prefix='login')
    register_form = RegistrationForm(prefix='register')

    if login_form.validate_on_submit() and login_form.submit.data:
        user = User.query.filter_by(email=login_form.email.data).first()
        if user and check_password_hash(user.password, login_form.password.data):
            login_user(user)
            flash('Logged in successfully.', 'success')
            return redirect(url_for('index'))
        else:
            flash('Login unsuccessful. Check email and password.', 'danger')

    if register_form.validate_on_submit() and register_form.submit.data:
        hashed_password = generate_password_hash(register_form.password.data)
        default_permission = Permission.query.filter_by(permission_name='user').first()
        user = User(username=register_form.username.data,
                    email=register_form.email.data,
                    password=hashed_password,
                    permission=default_permission)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created! You can now log in.', 'success')
        return redirect(url_for('log'))

    return render_template('log.html', login_form=login_form, register_form=register_form)

